# Torch Segment



A deep learning image segmentation library built of top of PyTorch.